import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consumer-home',
  templateUrl: './consumer-home.page.html',
  styleUrls: ['./consumer-home.page.scss'],
})
export class ConsumerHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
